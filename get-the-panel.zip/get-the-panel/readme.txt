=== Get The Panel ===
Contributors: Vinhjaxt
Tags: get, panel, php, filemanager
Stable tag: 1.0.3b
License: MIT


Get the panel

== Change Log ==

= 0.1 =
* First stable release
* Time invested for this release: 1day